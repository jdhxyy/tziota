__version__ = '1.1'

from .udp_server import *
