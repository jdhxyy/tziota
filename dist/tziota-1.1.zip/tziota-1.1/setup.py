from setuptools import setup, find_packages
setup(
        name="tziota",
        version="1.1",
        description="",
        author="jdh99",
        url="",
        packages=find_packages(),
    )
