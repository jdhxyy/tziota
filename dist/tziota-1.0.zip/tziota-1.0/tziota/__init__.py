__version__ = '1.0'

from .udp_server import *
