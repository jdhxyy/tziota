from setuptools import setup, find_packages
setup(
        name="tziota",
        version="1.0",
        description="",
        author="jdh99",
        url="",
        packages=find_packages(),
    )
